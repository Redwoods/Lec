def vartest2(z):
    z = z + 1

vartest2(3)
print(z)
