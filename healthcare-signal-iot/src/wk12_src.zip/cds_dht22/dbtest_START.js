// dbtest.js
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/test');

var SensorSchema = new mongoose.Schema({
	data: String,
	created: Date
});

// data model
var Sensor = mongoose.model("Sensor", );

var sensor1 = new Sensor({data:'124', created: });
sensor1.;

var sensor2 = new Sensor({data:'573', created: });
sensor2.;

console.log("Sensor data were saved in MongoDB");
