// index_hsnn.js

var myinfo = require('./hs00info');

myinfo("hs00", "Redwoods", '010-1234-5678');

myinfo("hs77", "HCit", '010-5678-1234');