// hsnninfo.js

module.exports = function(id, name, phone) {
	console.log("My Info");
	console.log("ID : " + id);
	console.log("Name : " + name);
	console.log("Phone : " + phone +"\n");
}